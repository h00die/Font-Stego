﻿Imports Word = Microsoft.Office.Interop.Word
Imports System.IO


Public Class frmOpenDocument

    Private Sub bntBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bntBrowse.Click
        Using ofd As New OpenFileDialog
            ofd.Filter = "Microsoft Word (*.doc)|*.doc"
            ofd.Title = "Select File"

            If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
                lblPromptFileName.Text = ofd.FileName
            End If
        End Using
    End Sub

    Private Sub btnRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRun.Click

        Dim objWordApp As Word.Application
        Dim wordFile As Word.Document
        Dim lettercount As Long

        Dim characterInWordCounter As Integer
        Dim characterToScan As Word.Range
        Dim colorcode As String
        Dim fontsize As String

        Dim ColorList As New ArrayList()
        Dim FontList As New ArrayList()

        Dim tempItemFromColorList As String
        Dim tempItemFromFontList As String
        Dim stringWasFound As Boolean = False
        Dim fontWasFound As Boolean = False
        Dim substring As String
        Dim numberOfTimesFound As Integer
        Dim numberofTimesFoundfont As Integer
        Dim numberOfTimesFoundcolorper As Integer
        Dim numberOfTimesFoundfontper As Integer
        Dim colorpercent As String
        Dim fontpercent As String

        Dim hitEOF As Boolean = False


        objWordApp = New Word.Application

        'Show the Word application window if checked.
        objWordApp.Visible = IIf(chkShowDoc.Checked, True, False)

        'Open an existing document.
        objWordApp.Documents.Open(lblPromptFileName.Text)
        wordFile = objWordApp.ActiveDocument

        'Character Count
        lettercount = wordFile.Characters.Count

        'Do not believe this is needed
        'rng = wordFile.Range
        'rng.Select()

        characterInWordCounter = 0

        'Ensures result listboxes are empty
        frmResults.lstColorCount.Items.Clear()
        frmResults.lstFontCount.Items.Clear()
        frmResults.lstDebug.Items.Clear()

        ProgressBar1.Maximum = lettercount

        For characterinbitstring As Long = 0 To lettercount - 1
            While Not IsCharValidForEncoding(wordFile.Range(characterInWordCounter, characterInWordCounter + 1))
                If characterInWordCounter >= lettercount - 1 Then 'we hit EOF, bail out!
                    GoTo hitEOF
                End If
                characterInWordCounter = characterInWordCounter + 1
            End While

            ProgressBar1.Increment(1)
            If ProgressBar1.Value = ProgressBar1.Maximum Then
                frmResults.Show()
                Me.Close()
            End If


            'While Asc(wordFile.Range(characterInWordCounter, characterInWordCounter + 1).Text) < 32 Or Asc(wordFile.Range(characterInWordCounter, characterInWordCounter + 1).Text) > 125
            '    characterInWordCounter = characterInWordCounter + 1
            '    If characterInWordCounter = lettercount Then 'we hit EOF, bail out!
            '        Exit For
            '    End If
            'End While
            characterToScan = wordFile.Range(characterInWordCounter, characterInWordCounter + 1)
            characterInWordCounter = characterInWordCounter + 1
            colorcode = characterToScan.Font.Color
            fontsize = characterToScan.Font.Size
            'Dim debug As New ArrayList
            'debug.Add(colorcode & " " & fontsize)
            'frmResults.txtDebug.Text = frmResults.txtDebug.Text & colorcode & " " & fontsize & vbNewLine
            frmResults.lstDebug.Items.Add(colorcode & " " & fontsize)

            If ColorList.Count = 0 Or FontList.Count = 0 Then
                GoTo addfirstelement
            End If

            For x As Integer = 1 To ColorList.Count 'capacity may be wrong

                tempItemFromColorList = ColorList(x - 1)
                substring = Microsoft.VisualBasic.Left(tempItemFromColorList, tempItemFromColorList.IndexOf("="))
                If colorcode = substring Then
                    'we got a match
                    stringWasFound = True
                    numberOfTimesFound = Microsoft.VisualBasic.Right(tempItemFromColorList, tempItemFromColorList.Length - tempItemFromColorList.IndexOf("=") - 1)
                    numberOfTimesFound = numberOfTimesFound + 1
                    'overwrite the string with a new one
                    ColorList(x - 1) = (colorcode + "=" + CType(numberOfTimesFound, String))
                    Exit For
                End If
            Next

            For j As Integer = 1 To FontList.Count
                tempItemFromFontList = FontList(j - 1)
                substring = Microsoft.VisualBasic.Left(tempItemFromFontList, tempItemFromFontList.IndexOf("="))
                If fontsize = substring Then
                    'we got a match
                    fontWasFound = True
                    numberofTimesFoundfont = Microsoft.VisualBasic.Right(tempItemFromFontList, tempItemFromFontList.Length - tempItemFromFontList.IndexOf("=") - 1)
                    numberofTimesFoundfont = numberofTimesFoundfont + 1
                    'overwrite the string with a new one
                    FontList(j - 1) = (fontsize + "=" + CType(numberofTimesFoundfont, String))
                    Exit For
                End If

            Next

            If Not stringWasFound Then
addfirstelement:
                ColorList.Add(colorcode & "=" & "1")
            End If
            stringWasFound = False 'just to be safe

            If Not fontWasFound Then
                FontList.Add(fontsize & "=" & "1")
            End If
            fontWasFound = False
        Next



hitEOF:

        For j As Integer = 0 To ColorList.Count - 1
            frmResults.lstColorCount.Items.Add(ColorList(j))
            numberOfTimesFoundcolorper = Microsoft.VisualBasic.Right(ColorList(j), ColorList(j).Length - ColorList(j).IndexOf("=") - 1)
            colorpercent = numberOfTimesFoundcolorper / frmResults.lstDebug.Items.Count
            colorpercent = Math.Round(colorpercent * 100, 2).ToString & "%"
            frmResults.lstColorPer.Items.Add(colorpercent)
        Next

        For i As Integer = 0 To FontList.Count - 1
            frmResults.lstFontCount.Items.Add(FontList(i))
            numberOfTimesFoundfontper = Microsoft.VisualBasic.Right(FontList(i), FontList(i).Length - FontList(i).IndexOf("=") - 1)
            fontpercent = numberOfTimesFoundfontper / frmResults.lstDebug.Items.Count
            fontpercent = Math.Round(fontpercent * 100, 2).ToString & "%"
            frmResults.lstFontPer.Items.Add(fontpercent)
        Next

        frmResults.lblCharCount.Text = frmResults.lstDebug.Items.Count
        frmResults.Show()
        Me.Close()

        objWordApp.Documents.Close(Word.WdSaveOptions.wdDoNotSaveChanges)
        objWordApp.Quit()
        objWordApp = Nothing
    End Sub


    Private Function IsCharValidForEncoding(ByVal character As Word.Range) As Boolean
        'check to see if its null
        If character.Text = Nothing Then
            Return 0
        Else
            'check to see if it has length
            If character.Text.Length = 0 Then
                Return 0
            Else
                If Asc(character.Text) < 32 Or Asc(character.Text) > 125 Then
                    Return 0
                Else
                    Return 1
                End If
            End If
        End If
    End Function



    'Dim letterCount As Double = wordFile.Content.Characters.Count
    'Dim characterInWordCounter As Double = 0
    'Dim characterToEncode As Word.Range

    'For characterInBitString As Double = 0 To bitString.Length Step 3
    'filter for only useable characters
    'While Asc(wordFile.Range(characterInWordCounter, characterInWordCounter + 1).Text) < 32 Or Asc(wordFile.Range(characterInWordCounter, characterInWordCounter + 1).Text) > 125
    'characterInWordCounter = characterInWordCounter + 1
    'End While
    'characterToEncode = wordFile.Range(characterInWordCounter, characterInWordCounter + 1)
    'characterToEncode.Font.Color = Word.WdColor RGB(Mid(bitString, characterInBitString), Mid(bitString, characterInBitString + 1), Mid(bitString, characterInBitString + 2))
    'wordFile.Content.Characters(characterInWordCounter).Font.Color = RGB(Mid(bitString, characterInBitString), Mid(bitString, characterInBitString + 1), Mid(bitString, characterInBitString + 2))
    'If Debug Then Status.Text.AppendText(">Encoding Letter: " + characterToEncode.ToString + " with color: " + Mid(bitString, characterInBitString) + "," + Mid(bitString, characterInBitString + 1) + "," + Mid(bitString, characterInBitString + 2) + vbNewLine)
    'Next characterInBitString


    '-----------------------------------------------------------------
    'ByteToBitString
    'Inputs: inputByte (Byte)
    'Outputs: string
    'Description: This function is used to convert a byte like 255 into
    ' the string equivalent in bits like 11111111
    '
    'Notes: using 8 if statements with hard coded numbers turned out to
    ' be about 2x faster than doing a for 2^x type loop. This code
    ' might be ugly, but decently fast comparitively.
    '
    '------------------------------------------------------------------
    Private Function ByteToBitString(ByVal inputByte As Byte) As String
        'hard coding with if statements is alot quicker than one for loop doing the 2 ^ x... by about double speed!
        Dim bitString As String
        If inputByte >= 128 Then
            bitString = "1"
            inputByte = inputByte - 128
        Else
            bitString = "0"
        End If
        If inputByte >= 64 Then
            bitString = bitString & "1"
            inputByte = inputByte - 64
        Else
            bitString = bitString & "0"
        End If
        If inputByte >= 32 Then
            bitString = bitString & "1"
            inputByte = inputByte - 32
        Else
            bitString = bitString & "0"
        End If
        If inputByte >= 16 Then
            bitString = bitString & "1"
            inputByte = inputByte - 16
        Else
            bitString = bitString & "0"
        End If
        If inputByte >= 8 Then
            bitString = bitString & "1"
            inputByte = inputByte - 8
        Else
            bitString = bitString & "0"
        End If
        If inputByte >= 4 Then
            bitString = bitString & "1"
            inputByte = inputByte - 4
        Else
            bitString = bitString & "0"
        End If
        If inputByte >= 2 Then
            bitString = bitString & "1"
            inputByte = inputByte - 2
        Else
            bitString = bitString & "0"
        End If
        If inputByte >= 1 Then
            bitString = bitString & "1"
            inputByte = inputByte - 1
        Else
            bitString = bitString & "0"
        End If
        If inputByte <> 0 Then
            MsgBox("error in byte to bit conversion")
        End If
        ByteToBitString = bitString
    End Function


    '-----------------------------------------------------------------
    'LongToRGBString
    'Inputs: inputColor (Long)
    'Outputs: string
    'Description: This function is used to convert a long into
    ' the string equivalent in bits like 11111111. This is
    ' Needed because when a font color is set in RGB it is
    ' converted (by vb) to the Long equivalent and there is
    ' not a better way to get the RGB color back out of that.
    '
    '------------------------------------------------------------------
    Private Function LongToRGBString(ByVal inputColor As Long) As String
        'this gives red
        LongToRGBString = LongToRGBString & inputColor Mod &H100
        'take out the value, so we can get the rest of the colors
        inputColor = inputColor \ &H100
        'this gives green
        LongToRGBString = LongToRGBString & inputColor Mod &H100
        inputColor = inputColor \ &H100
        'this gives blue
        LongToRGBString = LongToRGBString & inputColor Mod &H100
    End Function

    '-----------------------------------------------------------------
    'BitStringToByte
    'Inputs: inputString (String, 8 length or program error)
    'Outputs: integer
    'Description: This function is used to convert a bit string like
    ' 11111111 to the byte equivalent like 255
    '
    'Notes: This is a reversed copy of ByteToBitString
    '
    '------------------------------------------------------------------
    Private Function BitStringToByte(ByVal inputString As String) As Integer
        Dim outputInteger As Integer 'This is used to save the result
        If Mid(inputString, 1, 1) = 1 Then
            outputInteger = outputInteger + 128
        End If
        If Mid(inputString, 2, 1) = 1 Then
            outputInteger = outputInteger + 64
        End If
        If Mid(inputString, 3, 1) = 1 Then
            outputInteger = outputInteger + 32
        End If
        If Mid(inputString, 4, 1) = 1 Then
            outputInteger = outputInteger + 16
        End If
        If Mid(inputString, 5, 1) = 1 Then
            outputInteger = outputInteger + 8
        End If
        If Mid(inputString, 6, 1) = 1 Then
            outputInteger = outputInteger + 4
        End If
        If Mid(inputString, 7, 1) = 1 Then
            outputInteger = outputInteger + 2
        End If
        If Mid(inputString, 8, 1) = 1 Then
            outputInteger = outputInteger + 1
        End If
        BitStringToByte = outputInteger
    End Function

End Class
