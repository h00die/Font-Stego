﻿Imports Word = Microsoft.Office.Interop.Word
Imports System.IO

Public Class frmOpenDocument
    Private Sub bntBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bntBrowse.Click
        Using ofd As New OpenFileDialog
            ofd.Filter = "Microsoft Word (*.doc)|*.doc"
            ofd.Title = "Select File"

            If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
                txtPromptFileName.Text = ofd.FileName
            End If
        End Using
    End Sub

    Private Sub btnRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRun.Click

        Dim objWordApp As Word.Application = New Word.Application
        Dim wordFile As Word.Document
        Dim lettercount As Long
        Dim startTime As DateTime = DateTime.Now
        Dim executionTime As TimeSpan
        Dim characterInWordCounter As Integer = 0
        Dim characterToScan As Word.Range
        Dim fontsize As String
        Dim colorString As String
        Dim red As String
        Dim green As String
        Dim blue As String
        Dim LSBredArray As New ArrayList
        Dim LSBgreenArray As New ArrayList
        Dim LSBblueArray As New ArrayList
        Dim Fontarray As New ArrayList
        Dim ColorList As New ColorArrayList
        Dim FontList As New FontArrayList
        Dim hitEOF As Boolean = False

        'Open an existing document.
        objWordApp.Documents.Open(txtPromptFileName.Text)
        wordFile = objWordApp.ActiveDocument

        'Character Count
        lettercount = wordFile.Characters.Count

        'Ensures result listbox is empty
        frmResults.lstDebug.Items.Clear()

        ProgressBar1.Maximum = lettercount

        'For Loop to check if character is valid, ignores invisible characters
        For characterinbitstring As Long = 0 To lettercount - 1
            While Not IsCharValidForEncoding(wordFile.Range(characterInWordCounter, characterInWordCounter + 1))
                If characterInWordCounter >= lettercount - 1 Then 'we hit EOF, bail out!
                    GoTo hitEOF
                End If
                characterInWordCounter = characterInWordCounter + 1
            End While

            'Loads active character in range
            characterToScan = wordFile.Range(characterInWordCounter, characterInWordCounter + 1)

            'Automatically sets RGB value if color is "Automatic"
            If characterToScan.Font.Color = Word.WdColor.wdColorAutomatic Then
                colorString = "000000000"
                red = "00000000"
                green = "00000000"
                blue = "00000000"

            Else
                'Gets RGB values if color is not "Automatic"
                colorString = WdColorToRGBString(characterToScan.Font.Color, red, green, blue)
            End If

            'Adds LSB (Last 3 bits) of each color to corresponding array
            LSBredArray.Add(red)
            LSBgreenArray.Add(green)
            LSBblueArray.Add(blue)

            'Gets fontsize of current character
            fontsize = characterToScan.Font.Size

            'TEST - adds font size to font array
            Fontarray.Add(fontsize)

            'Used for debugging purposes
            frmResults.lstDebug.Items.Add(colorString & " " & fontsize)

            'h00die edit: this is not working correctly yet, the contains is not overloaded correctly
            Dim colorToSearch As New colorItem 'create a new instance of the colorItem
            colorToSearch.color = colorString 'set the color name
            If ColorList.Contains(colorToSearch) > -1 Then 'i dont think this will work as it wont match the number
                colorToSearch = ColorList.Item(ColorList.Contains(colorToSearch)) 'import the count
                colorToSearch.count += 1 'increase the count
                ColorList.Item(ColorList.Contains(colorToSearch)) = colorToSearch 'reset the count
            Else
                ColorList.Add(New colorItem(colorString, 1))
            End If

            Dim fontToSearch As New fontItem
            fontToSearch.font = fontsize
            If FontList.Contains(fontToSearch) > -1 Then
                fontToSearch = FontList.Item(FontList.Contains(fontToSearch))
                fontToSearch.count += 1
                FontList.Item(FontList.Contains(fontToSearch)) = fontToSearch
            Else
                FontList.Add(New fontItem(fontsize, 1))
            End If

            'Increments progress bar
            ProgressBar1.Increment(1)
            If ProgressBar1.Value = ProgressBar1.Maximum Then
                frmResults.Show()
                Me.Close()
            End If

            'Adds one to variable for next character in document
            characterInWordCounter = characterInWordCounter + 1
        Next

        'EOF marker for the valid character loop
hitEOF:
        Dim ColorItemInArray As Integer
        Dim LSBcounter As Integer = 0
        Dim Fontcounter As Integer = 0
        Dim FontItemInArray As Integer

        'Looks for differences in adjacent character's color.
        For ColorItemInArray = 1 To LSBredArray.Count - 1
            If LSBredArray.Item(ColorItemInArray - 1) <> LSBredArray.Item(ColorItemInArray) Then
                LSBcounter = LSBcounter + 1
            End if
            If LSBgreenArray.Item(ColorItemInArray - 1) <> LSBgreenArray.Item(ColorItemInArray) Then
                LSBcounter = LSBcounter + 1
            End If
            If LSBblueArray.Item(ColorItemInArray - 1) <> LSBblueArray.Item(ColorItemInArray) Then
                LSBcounter = LSBcounter + 1
            End If
        Next

        'If adjacent character's font size are different, it adds one to the counter
        For FontItemInArray = 1 To Fontarray.Count - 1
            If Fontarray.Item(FontItemInArray - 1) <> Fontarray.Item(FontItemInArray) Then
                Fontcounter = Fontcounter + 1
            End If
        Next

        'Loads text box with number of differences of color and font
        frmResults.txtLSBCounter.Text = LSBcounter
        frmResults.txtFontCounter.Text = Fontcounter

        'Gets percentage of each color found in document
        ColorList.FindColorPercentage()
        frmResults.dgvColor.DataSource = ColorList

        'Gets percentage of each font found in document
        FontList.FindFontPercentage()
        frmResults.dgvSize.DataSource = FontList

        'Loads text box with amount of characters scanned
        frmResults.lblCharCount.Text = Fontarray.Count

        'Execution Time used for debugging purposes
        executionTime = DateTime.Now - startTime
        frmResults.lstDebug.Items.Add("Execution Time: " + executionTime.Minutes.ToString("s:" + executionTime.Seconds.ToString + "ms:" + executionTime.Milliseconds.ToString))

        'Show Results form once document has finished scanning
        frmResults.Show()
        Me.Close()

        'Close document and clear variable
        objWordApp.Documents.Close(Word.WdSaveOptions.wdDoNotSaveChanges)
        objWordApp.Quit()
        objWordApp = Nothing
    End Sub

    Private Function IsCharValidForEncoding(ByVal character As Word.Range) As Boolean
        'Checks if character is null
        If character.Text = Nothing Then
            Return 0
        Else
            'Check if character has length
            If character.Text.Length = 0 Then
                Return 0
            Else
                'If characters text is larger than 32 or greater than 125 character is not valid
                If Asc(character.Text) < 32 Or Asc(character.Text) > 125 Then
                    Return 0
                Else
                    Return 1
                End If
            End If
        End If
    End Function

    '-----------------------------------------------------------------
    'ByteToBitString
    'Inputs: inputByte (Byte)
    'Outputs: string
    'Description: This function is used to convert a byte like 255 into
    ' the string equivalent in bits like 11111111
    '------------------------------------------------------------------
    Public Function ByteToBitString(ByVal inputByte As Byte) As String
        'Padding since leading 0s get cut off
        Return Convert.ToString(inputByte, 2).PadLeft(8, "0")
    End Function

    '-----------------------------------------------------------------
    'WdColorToRGBString
    'Inputs: inputColor (Word.WdColor)
    'Outputs: String
    'Description: This function is used to convert a long into
    ' the string equivalent in bits like 11111111. This is
    ' Needed because when a font color is set in RGB it is
    ' converted (by vb) to the Long equivalent and there is
    ' not a better way to get the RGB color back out of that.
    '------------------------------------------------------------------
    Public Function WdColorToRGBString(ByVal inputColor As Word.WdColor, ByRef red As String, ByRef green As String, ByRef blue As String) As String
        'Isolate R,G,B elements.        
        red = ByteToBitString((inputColor And &HFF).ToString.PadLeft(3, "0"))
        green = ByteToBitString(((inputColor And &HFF00) >> 8).ToString.PadLeft(3, "0"))
        blue = ByteToBitString(((inputColor And &HFF0000) >> 16).ToString.PadLeft(3, "0"))
        Return ((inputColor And &HFF) + (inputColor And &HFF00) + (inputColor And &HFF0000))
    End Function

    'Clicking exit button will close program
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
        frmResults.Close()
    End Sub

End Class

'Making our own array
Public Class ColorArrayList
    Inherits ArrayList
    'return -1 if its not there, return the index number if it is found
    Public Overloads Function Contains(ByVal item As Object) As Double
        Dim index As Integer
        For index = 0 To Me.Count - 1
            Dim it As colorItem = DirectCast(item, colorItem)
            Dim it2 As colorItem = DirectCast(Me(index), colorItem)
            If it.color = it2.color Then
                Return index
            End If
        Next index
        Return -1
    End Function

    'Find all of the usage percentages
    Public Function FindColorPercentage() As Boolean
        Dim total As Long = 0
        For index = 0 To Me.Count - 1
            Dim color As colorItem = DirectCast(Me(index), colorItem)
            total += color.count
        Next index

        For index = 0 To Me.Count - 1
            Dim color As colorItem = DirectCast(Me(index), colorItem)
            color.percentUsage = Format(CType((color.count / total), Double), "#.####") * 100
            Me(index) = color
        Next index
    End Function
End Class

Public Class FontArrayList
    Inherits ArrayList
    'Return -1 if its not there, return the index number if it is found
    Public Overloads Function Contains(ByVal item As Object) As Double
        Dim index As Integer
        For index = 0 To Me.Count - 1
            Dim it As fontItem = DirectCast(item, fontItem)
            Dim it2 As fontItem = DirectCast(Me(index), fontItem)
            If it.font = it2.font Then
                Return index
            End If
        Next index
        Return -1
    End Function
    'Find all of the usage percentages
    Public Function FindFontPercentage() As Boolean
        Dim total As Long = 0
        For index = 0 To Me.Count - 1
            Dim font As fontItem = DirectCast(Me(index), fontItem)
            total += font.count
        Next index

        For index = 0 To Me.Count - 1
            Dim font As fontItem = DirectCast(Me(index), fontItem)
            font.percentUsage = Format(CType((font.count / total), Double), "#.####") * 100
            Me(index) = font
        Next index
    End Function
End Class

Public Structure colorItem
    Public colorCode As String
    Public count As Long
    Public percentUsage As Double

    Public Sub New(ByVal color As String, ByVal value As Double)
        colorCode = color
        count = value
    End Sub

    Public Property color As String
        Get
            Return colorCode
        End Get
        Set(ByVal value As String)
            colorCode = value
        End Set
    End Property

    Public Property counter As Long
        Get
            Return count
        End Get
        Set(ByVal counter As Long)
            count = counter
        End Set
    End Property

    Public Property percentage As Double
        Get
            Return percentUsage
        End Get
        Set(ByVal percentage As Double)
            percentUsage = percentage
        End Set
    End Property

End Structure

Public Structure fontItem
    Public fontCode As String
    Public count As Long
    Public percentUsage As Double

    Public Sub New(ByVal font As String, ByVal value As Double)
        fontCode = font
        count = value
    End Sub

    Public Property font As String
        Get
            Return fontCode
        End Get
        Set(ByVal value As String)
            fontCode = value
        End Set
    End Property

    Public Property counter As Long
        Get
            Return count
        End Get
        Set(ByVal counter As Long)
            count = counter
        End Set
    End Property

    Public Property percentage As Double
        Get
            Return percentUsage
        End Get
        Set(ByVal percentage As Double)
            percentUsage = percentage
        End Set
    End Property

End Structure