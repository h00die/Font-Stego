﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmResults
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblCharCount = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chkDebug = New System.Windows.Forms.CheckBox()
        Me.lstDebug = New System.Windows.Forms.ListBox()
        Me.lblDebug = New System.Windows.Forms.Label()
        Me.cmdBack = New System.Windows.Forms.Button()
        Me.dgvColor = New System.Windows.Forms.DataGridView()
        Me.dgvSize = New System.Windows.Forms.DataGridView()
        Me.txtLSBCounter = New System.Windows.Forms.TextBox()
        Me.lblLSBcounter = New System.Windows.Forms.Label()
        Me.btnExport = New System.Windows.Forms.Button()
        Me.lblfontcounter = New System.Windows.Forms.Label()
        Me.txtFontCounter = New System.Windows.Forms.TextBox()
        CType(Me.dgvColor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvSize, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblCharCount
        '
        Me.lblCharCount.BackColor = System.Drawing.Color.White
        Me.lblCharCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCharCount.Location = New System.Drawing.Point(100, 17)
        Me.lblCharCount.Name = "lblCharCount"
        Me.lblCharCount.Size = New System.Drawing.Size(55, 19)
        Me.lblCharCount.TabIndex = 37
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 13)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "Character Count:"
        '
        'chkDebug
        '
        Me.chkDebug.AutoSize = True
        Me.chkDebug.Location = New System.Drawing.Point(177, 19)
        Me.chkDebug.Name = "chkDebug"
        Me.chkDebug.Size = New System.Drawing.Size(130, 17)
        Me.chkDebug.TabIndex = 40
        Me.chkDebug.Text = "Show Debug Window"
        Me.chkDebug.UseVisualStyleBackColor = True
        '
        'lstDebug
        '
        Me.lstDebug.FormattingEnabled = True
        Me.lstDebug.Location = New System.Drawing.Point(62, 281)
        Me.lstDebug.Name = "lstDebug"
        Me.lstDebug.Size = New System.Drawing.Size(165, 82)
        Me.lstDebug.TabIndex = 42
        Me.lstDebug.Visible = False
        '
        'lblDebug
        '
        Me.lblDebug.AutoSize = True
        Me.lblDebug.Location = New System.Drawing.Point(14, 281)
        Me.lblDebug.Name = "lblDebug"
        Me.lblDebug.Size = New System.Drawing.Size(42, 13)
        Me.lblDebug.TabIndex = 43
        Me.lblDebug.Text = "Debug:"
        Me.lblDebug.Visible = False
        '
        'cmdBack
        '
        Me.cmdBack.Location = New System.Drawing.Point(328, 13)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.Size = New System.Drawing.Size(72, 25)
        Me.cmdBack.TabIndex = 44
        Me.cmdBack.Text = "Back"
        Me.cmdBack.UseVisualStyleBackColor = True
        '
        'dgvColor
        '
        Me.dgvColor.AllowUserToAddRows = False
        Me.dgvColor.AllowUserToDeleteRows = False
        Me.dgvColor.AllowUserToOrderColumns = True
        Me.dgvColor.AllowUserToResizeColumns = False
        Me.dgvColor.AllowUserToResizeRows = False
        Me.dgvColor.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvColor.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvColor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvColor.Location = New System.Drawing.Point(12, 52)
        Me.dgvColor.Name = "dgvColor"
        Me.dgvColor.ReadOnly = True
        Me.dgvColor.RowHeadersVisible = False
        Me.dgvColor.Size = New System.Drawing.Size(388, 106)
        Me.dgvColor.TabIndex = 45
        '
        'dgvSize
        '
        Me.dgvSize.AllowUserToAddRows = False
        Me.dgvSize.AllowUserToDeleteRows = False
        Me.dgvSize.AllowUserToOrderColumns = True
        Me.dgvSize.AllowUserToResizeColumns = False
        Me.dgvSize.AllowUserToResizeRows = False
        Me.dgvSize.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSize.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvSize.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSize.Location = New System.Drawing.Point(12, 164)
        Me.dgvSize.Name = "dgvSize"
        Me.dgvSize.ReadOnly = True
        Me.dgvSize.RowHeadersVisible = False
        Me.dgvSize.Size = New System.Drawing.Size(388, 106)
        Me.dgvSize.TabIndex = 46
        '
        'txtLSBCounter
        '
        Me.txtLSBCounter.Location = New System.Drawing.Point(300, 286)
        Me.txtLSBCounter.Name = "txtLSBCounter"
        Me.txtLSBCounter.ReadOnly = True
        Me.txtLSBCounter.Size = New System.Drawing.Size(100, 20)
        Me.txtLSBCounter.TabIndex = 47
        '
        'lblLSBcounter
        '
        Me.lblLSBcounter.AutoSize = True
        Me.lblLSBcounter.Location = New System.Drawing.Point(233, 289)
        Me.lblLSBcounter.Name = "lblLSBcounter"
        Me.lblLSBcounter.Size = New System.Drawing.Size(67, 13)
        Me.lblLSBcounter.TabIndex = 48
        Me.lblLSBcounter.Text = "LSB Counter"
        '
        'btnExport
        '
        Me.btnExport.Location = New System.Drawing.Point(300, 342)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(103, 23)
        Me.btnExport.TabIndex = 49
        Me.btnExport.Text = "Export to Excel >>"
        Me.btnExport.UseVisualStyleBackColor = True
        '
        'lblfontcounter
        '
        Me.lblfontcounter.AutoSize = True
        Me.lblfontcounter.Location = New System.Drawing.Point(233, 315)
        Me.lblfontcounter.Name = "lblfontcounter"
        Me.lblfontcounter.Size = New System.Drawing.Size(68, 13)
        Me.lblfontcounter.TabIndex = 51
        Me.lblfontcounter.Text = "Font Counter"
        '
        'txtFontCounter
        '
        Me.txtFontCounter.Location = New System.Drawing.Point(300, 312)
        Me.txtFontCounter.Name = "txtFontCounter"
        Me.txtFontCounter.ReadOnly = True
        Me.txtFontCounter.Size = New System.Drawing.Size(100, 20)
        Me.txtFontCounter.TabIndex = 50
        '
        'frmResults
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(423, 373)
        Me.Controls.Add(Me.lblfontcounter)
        Me.Controls.Add(Me.txtFontCounter)
        Me.Controls.Add(Me.btnExport)
        Me.Controls.Add(Me.lblLSBcounter)
        Me.Controls.Add(Me.txtLSBCounter)
        Me.Controls.Add(Me.dgvSize)
        Me.Controls.Add(Me.dgvColor)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.lblDebug)
        Me.Controls.Add(Me.lstDebug)
        Me.Controls.Add(Me.chkDebug)
        Me.Controls.Add(Me.lblCharCount)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmResults"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Steganalysis Results"
        CType(Me.dgvColor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvSize, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblCharCount As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chkDebug As System.Windows.Forms.CheckBox
    Friend WithEvents lstDebug As System.Windows.Forms.ListBox
    Friend WithEvents lblDebug As System.Windows.Forms.Label
    Friend WithEvents cmdBack As System.Windows.Forms.Button
    Friend WithEvents dgvColor As System.Windows.Forms.DataGridView
    Friend WithEvents dgvSize As System.Windows.Forms.DataGridView
    Friend WithEvents txtLSBCounter As System.Windows.Forms.TextBox
    Friend WithEvents lblLSBcounter As System.Windows.Forms.Label
    Friend WithEvents btnExport As System.Windows.Forms.Button
    Friend WithEvents lblfontcounter As System.Windows.Forms.Label
    Friend WithEvents txtFontCounter As System.Windows.Forms.TextBox
End Class
