﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmResults
    'Used for debugging purposes. Makes debug listbox visible
    Private Sub chkDebug_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkDebug.CheckStateChanged
        If chkDebug.Checked Then
            lstDebug.Visible = True
            lblDebug.Visible = True
        Else
            lstDebug.Visible = False
            lblDebug.Visible = False
        End If
    End Sub

    'Goes back to analysis form
    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click
        Me.Hide()
        frmOpenDocument.Show()
    End Sub

    'Exports to Microsoft Excel
    Private Sub btnExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExport.Click
        Dim xlApp As Excel.Application
        Dim xlWorkBook As Excel.Workbook
        Dim xlColorSheet As Excel.Worksheet
        Dim xlFontSheet As Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim i As Integer
        Dim j As Integer

        'Opens Excel
        xlApp = New Microsoft.Office.Interop.Excel.Application
        xlApp.Visible = True
        xlWorkBook = xlApp.Workbooks.Add(misValue)
        xlColorSheet = xlWorkBook.Sheets("Sheet1")
        xlFontSheet = xlWorkBook.Sheets("Sheet2")

        'Renames Excel sheets
        xlColorSheet.Name = "Color"
        xlFontSheet.name = "Font Size"
        CType(xlWorkBook.Sheets("Sheet3"), Excel.Worksheet).Delete()

        'Set the column headers and desired formatting for the spreadsheet.
        With xlColorSheet
            .Range("A1").Value = "Color"
            .Range("A1").Font.Bold = True
            .Range("B1").Value = "Count"
            .Range("B1").Font.Bold = True
            .Range("C1").Value = "Percentage"
            .Range("C1").Font.Bold = True
        End With
        With xlFontSheet
            .Range("A1").Value = "Size"
            .Range("A1").Font.Bold = True
            .Range("B1").Value = "Count"
            .Range("B1").Font.Bold = True
            .Range("C1").Value = "Percentage"
            .Range("C1").Font.Bold = True
        End With

        '
        For i = 0 To dgvColor.RowCount - 1
            For j = 0 To dgvColor.ColumnCount - 1
                xlColorSheet.Columns(1).NumberFormat = "@"
                xlColorSheet.Cells(i + 2, j + 1) = dgvColor(j, i).Value.ToString
            Next
        Next

        For i = 0 To dgvSize.RowCount - 1
            For j = 0 To dgvSize.ColumnCount - 1
                xlFontSheet.Cells(i + 2, j + 1) = _
                    dgvSize(j, i).Value
            Next
        Next

        '***** DO I NEED THESE??***
        'xlWorkSheet.SaveAs("C:\vbexcel.xlsx")
        'xlWorkBook.Close()
        'xlApp.Quit()

        'releaseObject(xlApp)
        'releaseObject(xlWorkBook)
        'releaseObject(xlWorkSheet)

    End Sub

End Class