﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOpenDocument
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.bntBrowse = New System.Windows.Forms.Button()
        Me.txtPromptFileName = New System.Windows.Forms.Label()
        Me.lblFileName = New System.Windows.Forms.Label()
        Me.btnRun = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'bntBrowse
        '
        Me.bntBrowse.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bntBrowse.Location = New System.Drawing.Point(377, 9)
        Me.bntBrowse.Name = "bntBrowse"
        Me.bntBrowse.Size = New System.Drawing.Size(75, 23)
        Me.bntBrowse.TabIndex = 20
        Me.bntBrowse.Text = "Browse"
        Me.bntBrowse.UseVisualStyleBackColor = True
        '
        'txtPromptFileName
        '
        Me.txtPromptFileName.BackColor = System.Drawing.Color.White
        Me.txtPromptFileName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPromptFileName.Location = New System.Drawing.Point(75, 9)
        Me.txtPromptFileName.Name = "txtPromptFileName"
        Me.txtPromptFileName.Size = New System.Drawing.Size(296, 23)
        Me.txtPromptFileName.TabIndex = 19
        Me.txtPromptFileName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFileName
        '
        Me.lblFileName.AutoSize = True
        Me.lblFileName.ForeColor = System.Drawing.Color.Black
        Me.lblFileName.Location = New System.Drawing.Point(12, 14)
        Me.lblFileName.Name = "lblFileName"
        Me.lblFileName.Size = New System.Drawing.Size(57, 13)
        Me.lblFileName.TabIndex = 18
        Me.lblFileName.Text = "File Name:"
        '
        'btnRun
        '
        Me.btnRun.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnRun.Location = New System.Drawing.Point(377, 41)
        Me.btnRun.Name = "btnRun"
        Me.btnRun.Size = New System.Drawing.Size(75, 23)
        Me.btnRun.TabIndex = 32
        Me.btnRun.Text = "Run"
        Me.btnRun.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.ForeColor = System.Drawing.Color.Lime
        Me.ProgressBar1.Location = New System.Drawing.Point(15, 70)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(437, 28)
        Me.ProgressBar1.TabIndex = 34
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(377, 106)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 35
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmOpenDocument
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(464, 141)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.btnRun)
        Me.Controls.Add(Me.bntBrowse)
        Me.Controls.Add(Me.txtPromptFileName)
        Me.Controls.Add(Me.lblFileName)
        Me.Name = "frmOpenDocument"
        Me.Text = "Steganalysis for Text Steganography"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents bntBrowse As System.Windows.Forms.Button
    Friend WithEvents txtPromptFileName As System.Windows.Forms.Label
    Friend WithEvents lblFileName As System.Windows.Forms.Label
    Friend WithEvents btnRun As System.Windows.Forms.Button
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents btnExit As System.Windows.Forms.Button

End Class
